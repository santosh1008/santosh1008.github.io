---
layout: page
title: "About"
permalink: /about/
---

Hello, I’m **Santhosh Tolle** — a SOC Analyst with a passion for cybersecurity.  

On this blog, I share what I learn in my work: incident response, threat hunting, tools, techniques, etc.  

You’ll find posts about practical problems, tutorials, and my thoughts on how to improve.  
