---
layout: page
title: "Contact"
permalink: /contact/
---

If you want to reach out:

- GitHub: [santosh1008](https://github.com/santosh1008)  
- Email: your-email@example.com  
