---
layout: home
title: "Home"
permalink: /
---

Welcome to my site.  
Here I write about cybersecurity, SOC analysis, tools, and my learning journey.  
Feel free to explore the blog for articles, or read more about me.  
